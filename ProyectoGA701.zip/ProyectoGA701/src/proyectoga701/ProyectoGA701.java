/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyectoga701;

/**
 *
 * @author DELL
 */
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
public class ProyectoGA701 {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        String usuario= "root";
        String password= "Lauraadsosena";
        String url= "jdbc:mysql://localhost:3306/Prevention";
        Connection conexion;
        Statement statement;
        ResultSet rs;
        
  
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ProyectoGA701.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        try {
            conexion=DriverManager.getConnection(url,usuario,password);
            statement=conexion.createStatement();
            rs=statement.executeQuery("SELECT * FROM ESTUDIANTE");
            rs.next();
            do{
                System.out.println(rs.getInt("id_estudiante")+":"+ rs.getString("nombre"));
            }while(rs.next()); 
            
            //Insert
            statement.executeUpdate("INSERT INTO ESTUDIANTE VALUES (125947,'FREDY Quiroz','23','Mantenimiento')");
             do{
                System.out.println("");
            }while(rs.next()); 
             
             //Update
             statement.executeUpdate("UPDATE ESTUDIANTE SET nombre='Carlos Quiroz' WHERE id=1458764");
             do{
                System.out.println("");
            }while(rs.next()); 
             
            //delete
             statement.executeUpdate("DELETE FROM  ESTUDIANTE WHERE id=102564");
             do{
                System.out.println("");
            }while(rs.next()); 
             
        } catch (SQLException ex) {
            Logger.getLogger(ProyectoGA701.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
